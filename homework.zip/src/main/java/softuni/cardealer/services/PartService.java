package softuni.cardealer.services;


import java.io.IOException;

public interface PartService {
    void seedParts() throws Exception;
}
